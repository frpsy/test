#ifndef LIBA_H
#define LIBA_H

void libA_func(void);

#endif
