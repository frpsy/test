#ifndef LIBA_SUB_H
#define LIBA_SUB_H

void libA_sub_func(void);

#endif
