#include <stdio.h>
#include "libA_sub.h"

void libA_sub_func(void) {
    printf("libA_sub_func called\n");
}
