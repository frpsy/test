#include <stdio.h>

int main(void)
{
    printf("Main app start\n");
    libA_sub_func();
    return 0;
}
