#ifndef LIBB_H
#define LIBB_H

void libB_func(void);

#endif
