#ifndef LIBB_SUB_H
#define LIBB_SUB_H

void libB_sub_func(void);

#endif
