#include <stdio.h>

void libB_sub_func(void) {
    printf("libB_sub_func called\n");
}
